package net.osmangazi;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Lahmacun: açlığı doldurur, ayrıca 7 kalp (14 can) iyileştirir. */
public class LahmacunItem extends Item {
    public LahmacunItem(Item.Properties p) { super(p); }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack r = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide()) entity.heal(14.0F);
        return r;
    }
}
